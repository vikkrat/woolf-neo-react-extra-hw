export const selectFilter = state => state.filters;
