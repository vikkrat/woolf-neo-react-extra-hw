import RegistrationForm from '../../components/RegistrationForm/RegistrationForm';

const RegistrationPage = () => {
  return (
    <section>
      <h1>Register</h1>
      <RegistrationForm />
    </section>
  );
};

export default RegistrationPage;
